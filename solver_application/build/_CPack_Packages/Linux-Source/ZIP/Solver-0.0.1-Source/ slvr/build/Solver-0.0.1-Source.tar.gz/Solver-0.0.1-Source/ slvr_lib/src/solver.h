#pragma once

void solve(float a, float b, float c, float& x1, float& x2);
